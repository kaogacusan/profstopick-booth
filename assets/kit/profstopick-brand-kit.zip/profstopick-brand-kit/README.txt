profstopick brand kit
Files from profstopick.com/kitchen-sink, for the booth team.

FOLDERS
  logo/            wordmark (word + badge), badge, word alone. "-white" files are for navy grounds.
  app-icons/       the app icon per school. 192 = small. 512-maskable = wide edge, phones crop it.
  school-marks/    one black shape per school
  drawings/        dark lines + blue fill, see-through ground. For light grounds.
  drawings-navy/   white lines + light-blue fill, see-through ground. For navy grounds.
  icons/           40 icons. Reference only, not used in the product.
  confetti/        10 small shapes, SVG. Color them in any editor (they come in #102a4e).
  share-cards/     the link preview card, 1200 x 630

COLORS
  Navy        #0d3b7a   share card ground
  Accent      #416ea8   the badge, the app color
  Accent deep #31567f
  Sky         #9ac0f4   the light word on the share card
  Tint        #eaeff6
  Paper       #f7f8fa   page ground
  Well        #eff1f5
  Ink         #16181d   text, the word
  Ink soft    #5a6170
  Line        #e5e8ee   hairline borders
  Score bands: Great #1f9d55, Good #84cc16, Okay #eab308, Poor #f97316, Bad #ef4444

TYPE
  Onest          body and headlines   https://fonts.google.com/specimen/Onest
  Red Hat Mono   codes and numbers    https://fonts.google.com/specimen/Red+Hat+Mono
  Headlines: Onest 800, tight letter spacing, one word in blue. "Pick the right prof."
  Cards: 4px corners, hairline borders.
  The peso sign is not in Onest or Red Hat Mono. Use the ₱ from Inter (Google Fonts), so it looks the same everywhere.

LINES
  Pick the right prof.
  Enlist smarter with ProfstoPick.
  Real student reviews, live section schedules and an advisor for enlistment.
